export const FILTER_TITLES = {
	PRICE_RANGE: "Price Range",
	CATEGORIES: "Categories",
	BRANDS: "Brands",
	SEATS: "Seats",
	COOLING: "Cooling",
};
