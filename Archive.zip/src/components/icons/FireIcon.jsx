import React from "react";

const FireIcon = () => {
	return <></>;
};

export default FireIcon;
