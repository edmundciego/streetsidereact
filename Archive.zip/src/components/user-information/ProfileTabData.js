export const ProfileTabData = [{}];
