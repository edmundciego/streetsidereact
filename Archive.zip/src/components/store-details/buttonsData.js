export const buttonsData = [
  { name: "Veg", value: "veg" },
  { name: "Non-Veg", value: "non_veg" },
];
