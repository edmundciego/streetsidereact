export const filterTypeItems = [
  {
    label: "Available for Now",
    value: "available_now",
    checked: false,
  },
  // {
  //   label: "Top Rated",
  //   value: "top_rated",
  //   checked: false,
  // },
  { label: "Discounted", value: "discounted", checked: false },
  //{ label: "From Campaign", value: "from_campaign", checked: false },
  {
    label: "Popular",
    value: "popular",
    checked: false,
  },

];