export const google_client_id =
  "296214775948-m3lf6r7jsj9ko8fpa5ebc88jrgc4ee0m.apps.googleusercontent.com";
export const fb_app_id = "";
export const appleLoginCredential = {
  serviceId: "com.streetsideco.stores",
  redirectURI: "https://streetsideapp.com/auth/callback", 
};

