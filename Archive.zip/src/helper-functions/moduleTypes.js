export const ModuleTypes = {
  GROCERY: "grocery",
  PHARMACY: "pharmacy",
  ECOMMERCE: "ecommerce",
  FOOD: "food",
  PARCEL: "parcel",
  RENTAL: "rental",
};
